# ALPHA V3
Real Node/Express starter store with admin dashboard and COD orders.

## Run locally
Install Node.js 20+, then in this folder run:
`npm install`
Set a strong password in the environment as `ADMIN_PASSWORD`, then:
`npm start`
Open `http://localhost:3000`.

## Admin
Click Admin. Add/edit/delete products, upload photos, and manage order statuses.

## Important before production
Change the default password. The starter uses `data/store.json` as a simple database. For a serious production store, use a managed database and persistent object/image storage.
